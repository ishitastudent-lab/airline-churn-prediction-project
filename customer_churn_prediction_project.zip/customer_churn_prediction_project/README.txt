Customer Churn Prediction Using Airline Loyalty Program Data

Project Objective:
To predict customer churn using airline loyalty data using Machine Learning techniques.

Model Used:
Random Forest Classifier

Model Accuracy:
88.56%

Files Included:
1. Customer_Churn.ipynb
2. Customer_Churn_Report.pdf
3. Customer Flight Activity.csv
4. Customer Loyalty History.csv

Author:
Ishita Malhotra